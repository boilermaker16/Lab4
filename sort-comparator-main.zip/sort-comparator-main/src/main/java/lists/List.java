package lists;

public interface List {
	
	public boolean isEmpty() throws Exception;
	public void insert(Object obj, int index) throws Exception; // insert at index of list
	public Object remove(int index) throws Exception; // remove node from list at given index
	
}