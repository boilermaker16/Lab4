package stacks;

public class StackNode {
	
	public Object data;
	public StackNode next;
	
}